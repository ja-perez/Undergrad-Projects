Javier Perez
10/18/2022
CS 422
Project 2 Report

Write-up 1:
    1.               K = 1:  K = 3:  K = 5:
        test1   =       1       1       1
        test2   =      -1       1       1
        test3   =       1       1       1
        test4   =      -1      -1      -1
        test5   =       1      -1       1
        test6   =      -1       1      -1
        test7   =       1      -1      -1
        test8   =      -1       1       1
        test9   =       1       1       1
        test10  =      -1      -1      -1
    2.
        Best K = 5

Write-up 2:
    Random mu = [[5 1]
                   [2 1]]
    K = 2: mu = [[7 4]
                 [1 3]]
    Using previous mu and one extra random mu.
    mu = [[5  1]
          [2  1]
          [7  4]]
    K = 3: mu = [[4.5     1]
                 [1.75 3.38]
                 [8     4.8]]
    Increasing K seems to have increased the precision of our cluster
    centers.

3. See Image